# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class ChinapcItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    datatime = scrapy.Field()   #时间
    allSF = scrapy.Field()   #省份数量
    newQZ = scrapy.Field()   #新增确诊
    newZZ = scrapy.Field()   #新增重症
    newSW = scrapy.Field()   #新增死亡
    newZY = scrapy.Field()   #新增治愈
    newYS = scrapy.Field()   #新增疑似
    allQZ = scrapy.Field()   #累计确诊
    allZZ = scrapy.Field()   #现有重症
    allSW = scrapy.Field()   #累计死亡
    allCY = scrapy.Field()   #累计治愈
    allYS = scrapy.Field()   #累计疑似
    allgo = scrapy.Field()   #累计追踪
    dayJC = scrapy.Field()   #当日解除
    allGc = scrapy.Field()   #累计观察
    GATall = scrapy.Field()   #港澳台确诊
    XGall = scrapy.Field()   #香港
    AMall = scrapy.Field()   #澳门
    TWall = scrapy.Field()   #台湾
