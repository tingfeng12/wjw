# -*- coding: utf-8 -*-
import scrapy
import chinapc.items
import re


class ChinaSpider(scrapy.Spider):
    name = 'china'
    # allowed_domains = ['http://www.nhc.gov.cn/xcs/yqtb/202001/1c259a68d81d40abb939a0781c1fe237.shtml']
    start_urls = ['http://www.nhc.gov.cn/xcs/yqtb/list_gzbd.shtml']

    def parse(self, response):
        print('response')
        print(response)
        newhref= response.xpath("//ul[@class='zxxx_list']/li/a/@href")
        newhref = 'http://www.nhc.gov.cn/'.join(newhref)
        print(newhref)
        yield scrapy.Request(
            newhref,
            callback=self.parse_new,
        )
    def parse_new(self, response):
        print('response')
        print(response)
        data = ''.join(response.xpath("//div[@id='xw_box']/p/text()").extract()).strip()
        print('data')
        print(data)
        print(len(data))
        print(data[0])
        item = chinapc.items.ChinapcItem()
        item['datatime'] = re.match('.*日',data[0])[0];
        item['allSF'] = re.search('\d+个省',data[0])[0];
        item['newQZ'] = re.search('新增确诊病例\d+',data[0])[0];
        item['newZZ'] = re.search('新增重症病例\d+',data[0])[0];
        item['newSW'] = re.search('新增死亡病例\d+',data[0])[0];
        item['newZY'] = re.search('新增治愈出院病例\d+',data[0])[0];
        item['newYS'] = re.search('新增疑似病例\d+',data[0])[0];
        item['allQZ'] = re.search('确诊病例\d+',data[1])[0];
        item['allZZ'] = re.search('重症病例\d+',data[1])[0];
        item['allSW'] = re.search('累计死亡病例\d+',data[1])[0];
        item['allCY'] = re.search('累计治愈出院病例\d+',data[1])[0];
        item['allYS'] = re.search('共有疑似病例\d+',data[1])[0];
        item['allgo'] = re.search('密切接触者\d+',data[2])[0];
        item['dayJC'] = re.search('当日解除医学观察\d+',data[2])[0];
        item['allGc'] = re.search('\d+人正在接受医学观察',data[2])[0];
        item['GATall'] = re.search('通报确诊病例\d+',data[3])[0];
        item['XGall'] = re.search('香港特别行政区\d+',data[3])[0];
        item['AMall'] = re.search('澳门特别行政区\d+',data[3])[0];
        item['TWall'] = re.search('台湾地区\d+',data[3])[0];

        print(item)
        yield item