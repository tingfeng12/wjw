# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import pymysql

class ChinapcPipeline(object):
    def __init__(self):
        # 连接数据库
        self.connect = pymysql.connect(
            host='127.0.0.1',  # 数据库地址
            port=3306,  # 数据库端口
            db='wjw',  # 数据库名
            user='root',  # 数据库用户名
            passwd='123',  # 数据库密码
            charset='utf8',  # 编码方式
            use_unicode=True)
        self.cursor = self.connect.cursor();

    def process_item(self, item, spider):
        self.cursor.execute("""
                                insert into china(datatime,allSF,newQZ,newZZ,newSW,newZY,newYS,allQZ,allZZ,allSW,allCY,allYS,allgo,dayJC,allGc,GATall,XGall,AMall,TWall) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                                """, (
            item['datatime'], item['allSF'], item['newQZ'], item['newZZ'], item['newSW'], item['newZY'], item['newYS'],
            item['allQZ'], item['allZZ'], item['allSW'], item['allCY'], item['allYS'], item['allgo'], item['dayJC'],
            item['allGc'],item['GATall'],item['XGall'],item['AMall'],item['TWall']))

        self.connect.commit()
        return item
