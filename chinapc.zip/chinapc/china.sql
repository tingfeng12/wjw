/*
Navicat MySQL Data Transfer

Source Server         : cr19mms
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : wjw

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2020-02-04 21:22:53
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for china
-- ----------------------------
DROP TABLE IF EXISTS `china`;
CREATE TABLE `china` (
  `id` int(11) NOT NULL,
  `datatime` varchar(255) DEFAULT NULL COMMENT '时间',
  `allSF` varchar(255) DEFAULT NULL COMMENT '省份数量',
  `newQZ` varchar(255) DEFAULT NULL COMMENT '新增确诊',
  `newZZ` varchar(255) DEFAULT NULL COMMENT '新增重症',
  `newSW` varchar(255) DEFAULT NULL COMMENT '新增死亡',
  `newZY` varchar(255) DEFAULT NULL COMMENT '新增治愈',
  `newYS` varchar(255) DEFAULT NULL COMMENT '新增疑似',
  `allQZ` varchar(255) DEFAULT NULL COMMENT '累计确诊',
  `allZZ` varchar(255) DEFAULT NULL COMMENT '现有重症',
  `allSW` varchar(255) DEFAULT NULL COMMENT '累计死亡',
  `allCY` varchar(255) DEFAULT NULL COMMENT '累计治愈',
  `allYS` varchar(255) DEFAULT NULL COMMENT '累计疑似',
  `allgo` varchar(255) DEFAULT NULL COMMENT '累计追踪',
  `dayJC` varchar(255) DEFAULT NULL COMMENT '当日解除',
  `allGc` varchar(255) DEFAULT NULL COMMENT '累计观察',
  `GATall` varchar(255) DEFAULT NULL COMMENT '港澳台确诊',
  `XGall` varchar(255) DEFAULT NULL COMMENT '香港',
  `AMall` varchar(255) DEFAULT NULL COMMENT '澳门',
  `TWall` varchar(255) DEFAULT NULL COMMENT '台湾',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
